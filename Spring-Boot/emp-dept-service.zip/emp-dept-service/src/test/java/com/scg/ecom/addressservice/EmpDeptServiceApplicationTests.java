package com.scg.ecom.addressservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpDeptServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
